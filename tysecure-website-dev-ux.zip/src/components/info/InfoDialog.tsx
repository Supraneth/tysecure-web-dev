import * as React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, ExternalLink, Loader2 } from "lucide-react";
import { loadInfoDetail } from "@/content/loaders";
import type { InfoDetail } from "@/content/schema";
import { Link } from "react-router-dom";

type Kind = "prestation" | "module";

type Props = {
  kind: Kind;
  id: string;
  /** Label shown on trigger button */
  triggerLabel?: string;
  /** Optional: show next to title while loading */
  defaultTitle?: string;
  /** Optional: show a compact badge (price, etc.) in the header */
  headerBadge?: string;
  /** Button variants */
  triggerVariant?: React.ComponentProps<typeof Button>["variant"];
  triggerClassName?: string;
};

export function InfoDialog({
  kind,
  id,
  triggerLabel = "Plus d'infos",
  defaultTitle,
  headerBadge,
  triggerVariant = "outline",
  triggerClassName,
}: Props) {
  const [open, setOpen] = React.useState(false);
  const [detail, setDetail] = React.useState<InfoDetail | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);
  const requestRef = React.useRef(0);

  React.useEffect(() => {
    // Important: React 18 StrictMode (dev) mounts/unmounts effects twice.
    // Avoid "cancelled" flags that can prevent finally() from clearing loading.
    if (!open) return;
    if (detail) return;

    const reqId = ++requestRef.current;
    setLoading(true);
    setError(null);

    loadInfoDetail(kind, id)
      .then((d) => {
        if (requestRef.current !== reqId) return;
        setDetail(d);
      })
      .catch((e: unknown) => {
        if (requestRef.current !== reqId) return;
        const message = e instanceof Error ? e.message : "Impossible de charger les détails.";
        setError(message);
      })
      .finally(() => {
        if (requestRef.current !== reqId) return;
        setLoading(false);
      });
  }, [open, detail, kind, id]);

  React.useEffect(() => {
    // Reset state when closing so reopening always shows fresh content.
    if (open) return;
    setDetail(null);
    setError(null);
    setLoading(false);
  }, [open]);

  const title = detail?.title ?? defaultTitle ?? "Détails";
  const subtitle = detail?.subtitle;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button type="button" variant={triggerVariant} className={triggerClassName} onClick={() => setOpen(true)}>
        {triggerLabel}
      </Button>

      <DialogContent className="max-w-[min(92vw,720px)] p-0 overflow-hidden">
        <div className="p-6 border-b border-border">
          <DialogHeader>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <DialogTitle className="font-display text-xl md:text-2xl font-bold leading-tight">
                  {title}
                </DialogTitle>
                {(subtitle || headerBadge) && (
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    {subtitle && (
                      <DialogDescription className="text-sm text-muted-foreground">
                        {subtitle}
                      </DialogDescription>
                    )}
                    {headerBadge && <Badge variant="secondary">{headerBadge}</Badge>}
                  </div>
                )}
              </div>

              {loading && (
                <span className="inline-flex items-center text-muted-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                  <span className="sr-only">Chargement</span>
                </span>
              )}
            </div>
          </DialogHeader>
        </div>

        <div className="max-h-[70vh] overflow-auto px-6 py-5">
          {error ? (
            <div className="rounded-xl border border-border bg-card p-4">
              <p className="font-medium">Désolé, un problème est survenu.</p>
              <p className="text-sm text-muted-foreground mt-1">{error}</p>
            </div>
          ) : !detail ? (
            <div className="space-y-3">
              <div className="h-4 w-2/3 rounded bg-muted animate-pulse" />
              <div className="h-4 w-full rounded bg-muted animate-pulse" />
              <div className="h-4 w-5/6 rounded bg-muted animate-pulse" />
              <div className="h-4 w-3/4 rounded bg-muted animate-pulse" />
            </div>
          ) : (
            <div className="space-y-6">
              <p className="text-base leading-relaxed">{detail.longDescription}</p>

              {detail.highlights?.length > 0 && (
                <section>
                  <h4 className="font-display text-lg font-bold mb-3">Points clés</h4>
                  <ul className="space-y-2">
                    {detail.highlights.map((h) => (
                      <li key={h} className="flex gap-2">
                        <Check className="w-4 h-4 mt-1 text-primary flex-none" aria-hidden="true" />
                        <span className="text-sm md:text-base">{h}</span>
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {detail.benefits?.length > 0 && (
                <section>
                  <h4 className="font-display text-lg font-bold mb-3">Bénéfices</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm md:text-base text-muted-foreground">
                    {detail.benefits.map((b) => (
                      <li key={b}>{b}</li>
                    ))}
                  </ul>
                </section>
              )}

              {detail.prerequisites?.length ? (
                <section>
                  <h4 className="font-display text-lg font-bold mb-3">Prérequis</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm md:text-base text-muted-foreground">
                    {detail.prerequisites.map((p) => (
                      <li key={p}>{p}</li>
                    ))}
                  </ul>
                </section>
              ) : null}

              {detail.options?.length ? (
                <section>
                  <h4 className="font-display text-lg font-bold mb-3">Options</h4>
                  <div className="grid gap-3">
                    {detail.options.map((o) => (
                      <div key={o.title} className="rounded-xl border border-border bg-card p-4">
                        <p className="font-medium">{o.title}</p>
                        <p className="text-sm text-muted-foreground mt-1">{o.description}</p>
                      </div>
                    ))}
                  </div>
                </section>
              ) : null}

              {(detail.duration || detail.price) && (
                <section className="rounded-xl border border-border bg-card p-4">
                  <div className="flex flex-wrap gap-4 text-sm">
                    {detail.duration && (
                      <div>
                        <p className="text-muted-foreground">Durée</p>
                        <p className="font-medium">{detail.duration}</p>
                      </div>
                    )}
                    {detail.price && (
                      <div>
                        <p className="text-muted-foreground">Tarif indicatif</p>
                        <p className="font-medium">{detail.price}</p>
                      </div>
                    )}
                  </div>
                  {detail.notes && <p className="text-xs text-muted-foreground mt-3">{detail.notes}</p>}
                </section>
              )}
            </div>
          )}
        </div>

        <div className="p-6 border-t border-border">
          <DialogFooter className="w-full flex-col sm:flex-row sm:justify-end gap-2">
            {detail?.cta?.href ? (
              detail.cta.href.startsWith("/") ? (
                <Button asChild>
                  <Link to={detail.cta.href}>
                    {detail.cta.label}
                    <ExternalLink className="w-4 h-4 ml-2" aria-hidden="true" />
                  </Link>
                </Button>
              ) : (
                <Button asChild>
                  <a href={detail.cta.href} target="_blank" rel="noreferrer noopener">
                    {detail.cta.label}
                    <ExternalLink className="w-4 h-4 ml-2" aria-hidden="true" />
                  </a>
                </Button>
              )
            ) : (
              <Button asChild>
                <Link to="/contact">
                  Discuter de mon besoin
                  <ExternalLink className="w-4 h-4 ml-2" aria-hidden="true" />
                </Link>
              </Button>
            )}
            <Button variant="outline" type="button" onClick={() => setOpen(false)}>
              Fermer
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}

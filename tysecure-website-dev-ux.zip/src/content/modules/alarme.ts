import type { InfoDetail } from "../schema";

const detail: InfoDetail = {
  "id": "alarme",
  "title": "Alarme & capteurs",
  "subtitle": "Protection active du domicile",
  "longDescription": "Déploiement de capteurs (ouverture, mouvement), sirènes, claviers, et scénarios d’armement. L’objectif : un système simple à utiliser, mais robuste, avec notifications et logique anti‑fausses alertes.",
  "highlights": [
    "Armement/désarmement (codes, tags, automatisations)",
    "Zones et temporisations (entrée/sortie)",
    "Notifications et journaux d’événements",
    "Interconnexions : éclairage dissuasif, vidéo, présence"
  ],
  "benefits": [
    "Meilleure réactivité et sérénité",
    "Expérience unifiée (pas d’apps multiples)",
    "Évolutif à mesure que le logement évolue"
  ],
  "prerequisites": [
    "Fondation Home Assistant + réseau validé",
    "Définition des zones à protéger"
  ],
  "duration": "1 jour",
  "price": "Selon périmètre",
  "cta": {
    "label": "Configurer une alarme",
    "href": "/contact"
  }
};

export default detail;

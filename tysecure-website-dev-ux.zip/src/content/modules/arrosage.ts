import type { InfoDetail } from "../schema";

const detail: InfoDetail = {
  "id": "arrosage",
  "title": "Arrosage connecté",
  "subtitle": "Jardin intelligent et économe",
  "longDescription": "Automatisez l’arrosage selon calendrier, météo et humidité (si capteurs). Gestion par zones, arrêt automatique en cas de pluie, et pilotage manuel rapide sur mobile.",
  "highlights": [
    "Gestion multi‑zones (électrovannes) + calendrier",
    "Automatisations météo (pluie/vent/température)",
    "Capteurs optionnels (humidité sol) pour aller plus loin",
    "Contrôle manuel immédiat (mobile)"
  ],
  "benefits": [
    "Économies d’eau",
    "Jardin plus simple à entretenir",
    "Moins d’oublis et de sur‑arrosage"
  ],
  "prerequisites": [
    "Accès au système existant (programmateur/électrovannes)",
    "Emplacement pour boîtier / alimentation"
  ],
  "duration": "0,5 à 1 jour",
  "price": "Selon zones et matériel",
  "cta": {
    "label": "Discuter arrosage",
    "href": "/contact"
  }
};

export default detail;

import type { InfoDetail } from "../schema";

const detail: InfoDetail = {
  "id": "chauffage",
  "title": "Gestion Thermique",
  "subtitle": "Pilotage chauffage par zones",
  "longDescription": "Optimisez confort et facture : thermostats connectés, programmation avancée, modes absence/nuit, et automatisations selon température, présence ou météo. Intégration possible pompe à chaleur selon modèles.",
  "highlights": [
    "Pilotage par zones + consignes intelligentes",
    "Programmation (calendriers) + modes (vacances, nuit, télétravail)",
    "Automatisations conditionnelles (fenêtre ouverte, présence)",
    "Tableaux de bord simplifiés pour mobile"
  ],
  "benefits": [
    "Confort stable (moins d’à‑coups)",
    "Économies d’énergie via régulation fine",
    "Meilleure visibilité (graphiques, historique)"
  ],
  "prerequisites": [
    "Accès au système de chauffage (thermostat, chaudière, PAC)",
    "Compatibilité matériel à valider à l’audit"
  ],
  "duration": "0,5 à 1,5 jour",
  "price": "690€ HT (indicatif)",
  "cta": {
    "label": "Valider la compatibilité",
    "href": "/contact"
  }
};

export default detail;

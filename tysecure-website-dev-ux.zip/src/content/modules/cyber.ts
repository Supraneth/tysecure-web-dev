import type { InfoDetail } from "../schema";

const detail: InfoDetail = {
  "id": "cyber",
  "title": "Cybersécurité Domotique",
  "subtitle": "Réduire la surface d’attaque",
  "longDescription": "Un module dédié à la sécurité de votre domotique : segmentation, accès distant durci, hygiène des identifiants, sauvegardes, et contrôles réguliers. Pensé pour une utilisation grand public mais solide.",
  "highlights": [
    "Isolation réseau des objets connectés",
    "Accès distant sécurisé + limitation des ports exposés",
    "Sauvegardes et restauration testée",
    "Recommandations pratiques (MFA, mises à jour, mots de passe)"
  ],
  "benefits": [
    "Moins de risques d’intrusion",
    "Installation plus fiable au quotidien",
    "Tranquillité et bonnes pratiques pérennes"
  ],
  "prerequisites": [
    "Accès admin à la box/routeur (ou routeur dédié)",
    "Inventaire des équipements connectés"
  ],
  "duration": "0,5 à 1 jour",
  "price": "Selon matériel réseau",
  "cta": {
    "label": "Sécuriser mon réseau",
    "href": "/contact"
  }
};

export default detail;

import type { InfoDetail } from "../schema";

const detail: InfoDetail = {
  "id": "eclairage",
  "title": "Éclairage intelligent",
  "subtitle": "Ambiances, scénarios et économies",
  "longDescription": "Pilotez vos éclairages pièce par pièce : scènes (lecture, cinéma, nuit), automatisations (présence, luminosité), et contrôle unifié sur mobile. Compatible Zigbee/Wi‑Fi selon matériel.",
  "highlights": [
    "Scènes et ambiances (couleur/température si applicable)",
    "Automatisations : détection présence, lever/coucher du soleil, modes (absent/nuit)",
    "Contrôle local via Home Assistant + raccourcis mobile",
    "Intégration possible avec alarme et vidéo (dissuasion)"
  ],
  "benefits": [
    "Confort immédiat et cohérent dans toute la maison",
    "Réduction de consommation via extinction automatique",
    "Expérience utilisateur simple (une seule app)"
  ],
  "prerequisites": [
    "Pack Foundation (ou Home Assistant déjà installé)",
    "Liste des zones et types d’éclairage (interrupteurs, ampoules, variateurs)"
  ],
  "duration": "0,5 à 1 jour",
  "price": "Selon nombre de points lumineux",
  "cta": {
    "label": "Ajouter ce module",
    "href": "/composition"
  }
};

export default detail;

import type { InfoDetail } from "../schema";

const detail: InfoDetail = {
  "id": "energie",
  "title": "Suivi Énergie",
  "subtitle": "Mesurer, comprendre, optimiser",
  "longDescription": "Suivez vos consommations (globale et par postes) et identifiez les dérives. Tableaux de bord énergie Home Assistant, alertes, et automatisations (heures creuses, délestage) selon configuration.",
  "highlights": [
    "Mesure conso (compteur, pinces, appareils compatibles)",
    "Dashboards énergie + historique",
    "Alertes en cas de dérive / surconsommation",
    "Automatisations : heures creuses, délestage, priorités"
  ],
  "benefits": [
    "Réduction de facture via décisions basées sur données",
    "Détection rapide d’anomalies",
    "Meilleure compréhension des postes énergivores"
  ],
  "prerequisites": [
    "Point de mesure (tableau électrique/compteur) à valider",
    "Compatibilité équipements à vérifier"
  ],
  "duration": "0,5 à 1 jour",
  "price": "Selon instrumentation",
  "cta": {
    "label": "Optimiser ma conso",
    "href": "/contact"
  }
};

export default detail;

import type { InfoDetail } from "../schema";

const detail: InfoDetail = {
  "id": "multiroom",
  "title": "Audio Multiroom",
  "subtitle": "Synchronisation et contrôle centralisé",
  "longDescription": "Diffusez votre musique dans plusieurs pièces, créez des groupes, et contrôlez le tout depuis Home Assistant. Intégrations selon équipements (AirPlay, Chromecast, Sonos, etc.).",
  "highlights": [
    "Groupes multi‑pièces + volumes synchronisés",
    "Scènes (réveil, soirée, détente)",
    "Contrôle via dashboards et automatisations",
    "Compatibilité selon matériel existant"
  ],
  "benefits": [
    "Confort et simplicité (une interface)",
    "Scènes audio contextuelles",
    "Réutilisation du matériel existant quand possible"
  ],
  "prerequisites": [
    "Écosystème audio existant ou choix à définir",
    "Réseau Wi‑Fi stable (ou Ethernet)"
  ],
  "duration": "0,5 jour",
  "price": "Selon équipements",
  "cta": {
    "label": "Étudier ma config audio",
    "href": "/contact"
  }
};

export default detail;

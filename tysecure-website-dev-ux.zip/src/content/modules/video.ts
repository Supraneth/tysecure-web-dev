import type { InfoDetail } from "../schema";

const detail: InfoDetail = {
  "id": "video",
  "title": "Vidéosurveillance",
  "subtitle": "Caméras locales + enregistrement + alertes",
  "longDescription": "Mettez en place une vidéo fiable et respectueuse de la confidentialité : caméras IP, enregistrement local (NVR), détection intelligente (selon modèles), et notifications ciblées.",
  "highlights": [
    "Caméras IP locales + flux sécurisés",
    "Enregistrement NVR (rétention selon stockage)",
    "Détection (mouvement / IA si disponible) + notifications",
    "Intégration avec alarme et éclairage"
  ],
  "benefits": [
    "Preuves vidéo en cas d’incident",
    "Alertes pertinentes (moins de bruit)",
    "Contrôle local des données"
  ],
  "prerequisites": [
    "Réseau stable (idéalement câblé ou Wi‑Fi maîtrisé)",
    "Emplacements caméras et angles à valider"
  ],
  "duration": "1 à 2 jours",
  "price": "890€ HT (indicatif)",
  "cta": {
    "label": "Évaluer mon installation",
    "href": "/contact"
  }
};

export default detail;

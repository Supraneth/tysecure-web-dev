import { z } from "zod";

export const infoCtaSchema = z.object({
  label: z.string().min(1),
  href: z.string().min(1),
});

export const infoOptionSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
});

export const infoDetailSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  subtitle: z.string().optional(),
  longDescription: z.string().min(1),
  highlights: z.array(z.string().min(1)).default([]),
  benefits: z.array(z.string().min(1)).default([]),
  prerequisites: z.array(z.string().min(1)).optional(),
  options: z.array(infoOptionSchema).optional(),
  duration: z.string().optional(),
  price: z.string().optional(),
  cta: infoCtaSchema.optional(),
  notes: z.string().optional(),
});

export type InfoDetail = z.infer<typeof infoDetailSchema>;

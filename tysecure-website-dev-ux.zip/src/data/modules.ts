import type { Module } from '@/hooks/useComposition';
import type { LucideIcon } from 'lucide-react';
import {
  Lightbulb,
  Thermometer,
  Video,
  Lock,
  Droplets,
  Zap,
  Music,
  ShieldCheck,
} from 'lucide-react';

export type ModuleCategory = 'Sécurité' | 'Confort' | 'Énergie' | 'Multimédia';

export type ModuleCatalogItem = Module & {
  icon: LucideIcon;
  category: ModuleCategory;
};

/**
 * Source of truth for modules.
 *
 * Rationale:
 * - Modules were previously duplicated between pages.
 * - The composition is persisted; centralizing the catalog allows re-sync later.
 */
export const MODULES_CATALOG: ModuleCatalogItem[] = [
  {
    id: 'eclairage',
    name: 'Éclairage Intelligent',
    price: '490€ HT',
    description:
      "Gestion centralisée de l'éclairage, scénarios ambiance, détection de présence, programmation circadienne.",
    icon: Lightbulb,
    category: 'Confort',
  },
  {
    id: 'chauffage',
    name: 'Gestion Thermique',
    price: '690€ HT',
    description:
      'Thermostat connecté, zones de chauffage, programmation avancée, intégration pompe à chaleur.',
    icon: Thermometer,
    category: 'Confort',
  },
  {
    id: 'video',
    name: 'Vidéosurveillance',
    price: '890€ HT',
    description:
      'Caméras IP locales, enregistrement NVR, détection IA, notifications intelligentes.',
    icon: Video,
    category: 'Sécurité',
  },
  {
    id: 'alarme',
    name: 'Alarme & Intrusion',
    price: '790€ HT',
    description:
      "Système d'alarme intégré, capteurs d'ouverture, sirène, modes jour/nuit/absent.",
    icon: Lock,
    category: 'Sécurité',
  },
  {
    id: 'arrosage',
    name: "Gestion de l'Eau",
    price: '390€ HT',
    description:
      'Arrosage automatique, détection de fuites, relevé de compteur, alertes consommation.',
    icon: Droplets,
    category: 'Confort',
  },
  {
    id: 'energie',
    name: 'Monitoring Énergétique',
    price: '590€ HT',
    description:
      'Suivi consommation temps réel, délestage, intégration panneaux solaires, dashboard dédié.',
    icon: Zap,
    category: 'Énergie',
  },
  {
    id: 'multiroom',
    name: 'Audio Multiroom',
    price: '690€ HT',
    description:
      'Sonos/Cast intégré, scénarios musicaux, commande vocale locale, synchronisation zones.',
    icon: Music,
    category: 'Multimédia',
  },
  {
    id: 'cyber',
    name: 'Pack Cyber+',
    price: '990€ HT',
    description:
      'Durcissement avancé, DNS Guard, VPN site-to-site, audit sécurité trimestriel.',
    icon: ShieldCheck,
    category: 'Sécurité',
  },
];

export const MODULES_BY_ID = new Map(MODULES_CATALOG.map((m) => [m.id, m] as const));

export const MODULE_CATEGORIES: { id: ModuleCategory; label: string }[] = [
  { id: 'Sécurité', label: 'Sécurité' },
  { id: 'Confort', label: 'Confort & quotidien' },
  { id: 'Énergie', label: 'Énergie' },
  { id: 'Multimédia', label: 'Multimédia' },
];

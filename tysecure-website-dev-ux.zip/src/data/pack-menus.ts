/**
 * Mapping between "packs" (prestations) and the modules automatically included.
 *
 * Keep this file dumb and dependency-free (no imports), so it can be used from
 * both UI pages and state logic without cycles.
 */

export type PackId =
  | 'pack-sentinel'
  | 'pack-cyber'
  | 'pack-guardian'
  | 'pack-signature';

/**
 * Canonical list of pack prestation IDs.
 * Useful for safely synchronizing state across pages without duplicating strings.
 */
export const PACK_IDS: PackId[] = [
  'pack-sentinel',
  'pack-cyber',
  'pack-guardian',
  'pack-signature',
];

export const PACK_INCLUDED_MODULE_IDS: Record<PackId, string[]> = {
  // CCTV + alarme
  'pack-sentinel': ['video', 'alarme'],
  // Résilience / durcissement
  'pack-cyber': ['cyber'],
  // Tout Sentinel + Cyber (+ éléments avancés hors-catalogue aujourd'hui)
  'pack-guardian': ['video', 'alarme', 'cyber'],
  // Sur-mesure : pas d'inclusion automatique côté catalogue (défini en atelier)
  'pack-signature': [],
};

export const REFERENCE_PACK_IDS: PackId[] = ['pack-sentinel', 'pack-cyber', 'pack-guardian'];

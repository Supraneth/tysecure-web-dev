import type { Prestation } from '@/hooks/useComposition';

/**
 * Source of truth for prestations.
 *
 * Why this exists:
 * - Prestations page used to define its own local list.
 * - When a user added a prestation to the composition, we stored the whole object
 *   (including the price) in Zustand + persisted it.
 * - If you later edited a price in the Prestations page, Composition would still
 *   show the old persisted price.
 *
 * By centralizing the catalog here, Composition can always re-sync display/pricing
 * from the latest catalog values.
 */
export const PRESTATIONS_CATALOG: Prestation[] = [
  // Obligatoires
  {
    id: 'audit',
    name: 'Audit (obligatoire)',
    price: '750€ HT',
    description:
      "Obligatoire avant la construction. Analyse complète de votre habitat, besoins, infrastructure réseau et électrique. Visite sur site, rapport détaillé, schéma d'architecture cible."
  },
  {
    id: 'pack-foundation',
    name: 'Pack TySecure Foundation (obligatoire)',
    price: 'A partir de 1500€ HT',
    description:
      "Pack présélectionné obligatoire : serveur Home Assistant, 1 VLAN, intégrations Zigbee/WiFi, jusqu'à 20 appareils, 5 automatisations + cybersécurité de base."
  },

  // Optionnels
  {
    id: 'pack-sentinel',
    name: 'Pack TySecure Sentinel',
    price: 'A partir de 500€ HT',
    description: 'CCTV + alarme.'
  },
  {
    id: 'pack-cyber',
    name: 'Pack TySecure Cyber',
    price: 'A partir de 600€ HT',
    description: 'Résilience, sauvegardes chiffrées, durcissement, preuves & contrôles.'
  },
  {
    id: 'pack-guardian',
    name: 'Pack TySecure Guardian',
    price: 'A partir de  1200€ HT',
    description:
      "Tout Sentinel + Cyber + implémentation de l'IA avancée (Frigate IA + assistant vocal custom)."
  },

  // Premium
  {
    id: 'pack-signature',
    name: 'Pack TySecure Signature',
    price: 'Sur-mesure',
    description:
      'Offre haut de gamme sur mesure, adaptée à des besoins très spécifiques.'
  }
];

export const PRESTATIONS_BY_ID = new Map(PRESTATIONS_CATALOG.map((p) => [p.id, p] as const));

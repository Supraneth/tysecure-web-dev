import { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerFooter,
  DrawerClose,
} from '@/components/ui/drawer';
import { InfoDialog } from '@/components/info/InfoDialog';
import { useComposition, type Prestation } from '@/hooks/useComposition';
import { PRESTATIONS_CATALOG, PRESTATIONS_BY_ID } from '@/data/prestations';
import { MODULES_CATALOG, MODULES_BY_ID, MODULE_CATEGORIES, type ModuleCatalogItem } from '@/data/modules';
import { PACK_INCLUDED_MODULE_IDS, REFERENCE_PACK_IDS, type PackId } from '@/data/pack-menus';
import { toast } from 'sonner';
import {
  ArrowRight,
  Check,
  CheckCircle,
  Plus,
  Lock,
  ClipboardList,
  Sparkles,
} from 'lucide-react';

const prestations: Prestation[] = PRESTATIONS_CATALOG;

function PrestationCard({
  prestation,
  isMandatory = false,
}: {
  prestation: Prestation;
  isMandatory?: boolean;
}) {
  const { prestations: selectedPrestations, addPrestation, removePrestation } = useComposition();
  const isSelected = selectedPrestations.some((p) => p.id === prestation.id);

  const handleToggle = () => {
    if (isMandatory) {
      toast.info('Cette prestation est obligatoire.');
      return;
    }

    if (isSelected) {
      removePrestation(prestation.id);
      toast.info(`${prestation.name} retiré de votre composition`);
    } else {
      addPrestation(prestation);
      toast.success(`${prestation.name} ajouté à votre composition`);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`relative p-6 rounded-2xl border transition-all duration-300 ${
        isSelected || isMandatory
          ? 'bg-primary/10 border-primary shadow-glow'
          : 'bg-card border-border hover:border-primary/30'
      }`}
    >
      {(isSelected || isMandatory) && (
        <div className="absolute top-4 right-4">
          <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
            <Check className="w-4 h-4 text-primary-foreground" />
          </div>
        </div>
      )}

      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="font-display text-xl font-bold">{prestation.name}</h3>
        {isMandatory && (
          <span className="mr-auto text-xs font-medium px-2 py-1 rounded-full bg-primary/10 text-primary shrink-0">
            Obligatoire
          </span>
        )}
      </div>

      <p className="price-tag text-2xl mb-4">{prestation.price}</p>
      <p className="text-muted-foreground text-sm mb-6">{prestation.description}</p>

      <div className="grid grid-cols-1 gap-2">
        <InfoDialog
          kind="prestation"
          id={prestation.id}
          defaultTitle={prestation.name}
          headerBadge={prestation.price}
          triggerVariant="outline"
          triggerClassName="w-full"
        />
        <Button
          variant={isSelected || isMandatory ? 'outline' : 'default'}
          className="w-full"
          onClick={handleToggle}
        >
          {isMandatory ? (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Inclus (obligatoire)
            </>
          ) : isSelected ? (
            <>
              <Check className="w-4 h-4 mr-2" />
              Sélectionné
            </>
          ) : (
            <>
              <Plus className="w-4 h-4 mr-2" />
              Ajouter à ma composition
            </>
          )}
        </Button>
      </div>
    </motion.div>
  );
}

function PackCard({
  pack,
  value,
  onSelect,
  includedModules,
  highlight,
}: {
  pack: Prestation;
  value: string;
  onSelect: (id: string) => void;
  includedModules: ModuleCatalogItem[];
  highlight?: string;
}) {
  const isActive = value === pack.id;

  return (
    <motion.div
      layout
      className={`relative rounded-2xl border p-6 transition-all duration-300 ${
        isActive ? 'bg-primary/10 border-primary shadow-glow' : 'bg-card border-border hover:border-primary/30'
      }`}
      onClick={() => onSelect(pack.id)}
    >
      <div className="flex items-start gap-3">
        <RadioGroupItem value={pack.id} id={`pack-${pack.id}`} aria-label={`Choisir ${pack.name}`} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-display text-lg md:text-xl font-bold">{pack.name}</h3>
            {highlight && <Badge variant="secondary">{highlight}</Badge>}
          </div>
          <p className="price-tag text-xl mt-1">{pack.price}</p>
          <p className="text-sm text-muted-foreground mt-3">{pack.description}</p>

          <div className="mt-4">
            <p className="text-xs text-muted-foreground mb-2">Modules inclus</p>
            {includedModules.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {includedModules.map((m) => (
                  <span
                    key={m.id}
                    className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-2.5 py-1 text-xs"
                  >
                    <m.icon className="w-3.5 h-3.5 text-primary" aria-hidden="true" />
                    <span className="text-foreground/90">{m.name}</span>
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">À définir (sur-mesure)</p>
            )}
          </div>

          <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div
              onClick={(e) => e.stopPropagation()}
              onKeyDown={(e) => e.stopPropagation()}
            >
              <InfoDialog
                kind="prestation"
                id={pack.id}
                defaultTitle={pack.name}
                headerBadge={pack.price}
                triggerVariant="outline"
                triggerClassName="w-full"
              />
            </div>
            <Button
              type="button"
              variant={isActive ? 'outline' : 'default'}
              className="w-full"
              onClick={(e) => {
                e.stopPropagation();
                onSelect(pack.id);
              }}
            >
              {isActive ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Pack choisi
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Choisir ce pack
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {isActive && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute top-4 right-4"
          aria-hidden="true"
        >
          <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center">
            <Check className="w-4 h-4 text-primary-foreground" />
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}

function ModuleMenuCard({
  module,
  included,
  selected,
  manualSelected,
  onToggle,
}: {
  module: ModuleCatalogItem;
  included: boolean;
  selected: boolean;
  manualSelected: boolean;
  onToggle: () => void;
}) {
  const Icon = module.icon;

  const status = included ? 'Inclus' : manualSelected ? 'Ajouté' : selected ? 'Sélectionné' : 'Optionnel';
  const statusVariant = included ? 'secondary' : manualSelected ? 'default' : 'outline';

  return (
    <motion.div
      layout
      className={`rounded-2xl border p-5 transition-colors ${
        included || manualSelected || selected ? 'bg-primary/5 border-primary/30' : 'bg-card border-border'
      }`}
    >
      <div className="flex items-start gap-4">
        <div className="pt-1">
          <Checkbox
            checked={selected || included}
            onCheckedChange={() => onToggle()}
            disabled={included}
            aria-label={`${included ? 'Inclus' : selected ? 'Retirer' : 'Ajouter'} ${module.name}`}
          />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-primary" aria-hidden="true" />
                </div>
                <div className="min-w-0">
                  <p className="font-display font-bold leading-tight truncate">{module.name}</p>
                  <p className="text-xs text-muted-foreground">{module.price}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <Badge variant={statusVariant as any}>{status}</Badge>
              {included && <Lock className="w-4 h-4 text-primary" aria-hidden="true" />}
            </div>
          </div>

          <p className="text-sm text-muted-foreground mt-3">{module.description}</p>

          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
            <InfoDialog
              kind="module"
              id={module.id}
              defaultTitle={module.name}
              headerBadge={module.price}
              triggerVariant="outline"
              triggerClassName="w-full"
            />
            <Button
              type="button"
              variant={included || selected ? 'outline' : 'default'}
              className="w-full"
              onClick={onToggle}
              disabled={included}
            >
              {included ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Inclus
                </>
              ) : selected ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Sélectionné
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function SelectionSummary({
  selectedPack,
  includedModules,
  addedModules,
  onReset,
}: {
  selectedPack: Prestation | null;
  includedModules: ModuleCatalogItem[];
  addedModules: ModuleCatalogItem[];
  onReset: () => void;
}) {
  return (
    <div className="p-6 rounded-2xl bg-card border border-border">
      <div className="flex items-center gap-2 mb-4">
        <ClipboardList className="w-5 h-5 text-primary" aria-hidden="true" />
        <h2 className="font-display text-xl font-bold">Récapitulatif</h2>
      </div>

      <div className="space-y-5 text-sm">
        <div>
          <p className="text-muted-foreground">Pack choisi</p>
          {selectedPack ? (
            <div className="mt-1">
              <p className="font-medium">{selectedPack.name}</p>
              <p className="text-muted-foreground">{selectedPack.price}</p>
            </div>
          ) : (
            <p className="mt-1 font-medium">Aucun pack — à la carte</p>
          )}
        </div>

        <div>
          <p className="text-muted-foreground">Modules inclus</p>
          {includedModules.length > 0 ? (
            <ul className="mt-2 space-y-1">
              {includedModules.map((m) => (
                <li key={m.id} className="flex items-center justify-between gap-3">
                  <span className="flex items-center gap-2 min-w-0">
                    <CheckCircle className="w-4 h-4 text-primary" aria-hidden="true" />
                    <span className="truncate">{m.name}</span>
                  </span>
                  <span className="text-muted-foreground shrink-0">{m.price}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-2 text-muted-foreground">—</p>
          )}
        </div>

        <div>
          <p className="text-muted-foreground">Modules ajoutés manuellement</p>
          {addedModules.length > 0 ? (
            <ul className="mt-2 space-y-1">
              {addedModules.map((m) => (
                <li key={m.id} className="flex items-center justify-between gap-3">
                  <span className="flex items-center gap-2 min-w-0">
                    <Plus className="w-4 h-4 text-primary" aria-hidden="true" />
                    <span className="truncate">{m.name}</span>
                  </span>
                  <span className="text-muted-foreground shrink-0">{m.price}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-2 text-muted-foreground">—</p>
          )}
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-2">
        <Link to="/composition">
          <Button variant="hero" className="w-full group">
            Voir ma composition
            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
          </Button>
        </Link>
        <Link to="/contact">
          <Button variant="outline" className="w-full">
            Discuter de mon besoin
          </Button>
        </Link>
        <Button variant="ghost" className="w-full text-muted-foreground" onClick={onReset}>
          Réinitialiser les options
        </Button>
      </div>
    </div>
  );
}

export default function Prestations() {
  const {
    prestations: selectedPrestations,
    modules: selectedModules,
    selectedPackId,
    manualModuleIds,
    addPrestation,
    removePrestation,
    addModule,
    removeModule,
    setSelectedPackId,
    resetKeepingMandatory,
  } = useComposition();

  const [summaryOpen, setSummaryOpen] = useState(false);

  // --- Mandatory base (idempotent) ---
  useEffect(() => {
    const mandatoryIds = new Set(['audit', 'pack-foundation']);
    const selectedIds = new Set(selectedPrestations.map((p) => p.id));
    prestations.forEach((p) => {
      if (mandatoryIds.has(p.id) && !selectedIds.has(p.id)) {
        addPrestation(p);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // NOTE:
  // We deliberately avoid deriving `selectedPackId` from `prestations` on every render.
  // It can create update loops when other actions touch prestations (even if the list is unchanged).
  // Consistency is guaranteed by:
  // - zustand migration (v2) +
  // - the sync effect below (selectedPackId => prestations).

  const allPackIds: PackId[] = ['pack-sentinel', 'pack-cyber', 'pack-guardian', 'pack-signature'];

  // --- Ensure prestations reflect selectedPackId (single pack max) ---
  useEffect(() => {
    const currentSelectedPackIds = selectedPrestations
      .map((p) => p.id)
      .filter((id): id is PackId => (allPackIds as string[]).includes(id));

    // Remove any pack that isn't the selected one
    currentSelectedPackIds.forEach((id) => {
      if (selectedPackId !== id) removePrestation(id);
    });

    // Add selected pack prestation if missing
    if (selectedPackId) {
      const exists = selectedPrestations.some((p) => p.id === selectedPackId);
      if (!exists) {
        const pack = PRESTATIONS_BY_ID.get(selectedPackId);
        if (pack) addPrestation(pack);
      }
    }
  }, [selectedPackId, selectedPrestations, addPrestation, removePrestation]);

  const includedModuleIds = useMemo(
    () => (selectedPackId ? PACK_INCLUDED_MODULE_IDS[selectedPackId] ?? [] : []),
    [selectedPackId]
  );

  // --- Auto-include modules when a pack is selected ---
  const prevPackIdRef = useRef<PackId | null>(null);
  useEffect(() => {
    const prevPackId = prevPackIdRef.current;
    const prevIncluded = prevPackId ? PACK_INCLUDED_MODULE_IDS[prevPackId] ?? [] : [];
    const nextIncluded = includedModuleIds;

    const nextIncludedSet = new Set(nextIncluded);
    const manualSet = new Set(manualModuleIds);

    // Remove modules that were included by the previous pack and are not kept manually.
    prevIncluded.forEach((id) => {
      if (!nextIncludedSet.has(id) && !manualSet.has(id)) {
        removeModule(id, { source: 'pack' });
      }
    });

    // Add modules included by the new pack.
    nextIncluded.forEach((id) => {
      const m = MODULES_BY_ID.get(id);
      if (!m) return;
      addModule({ id: m.id, name: m.name, price: m.price, description: m.description }, { source: 'pack' });
    });

    prevPackIdRef.current = selectedPackId;
  }, [selectedPackId, includedModuleIds, manualModuleIds, addModule, removeModule]);

  const mandatoryPrestations = useMemo(
    () => prestations.filter((p) => p.id === 'audit' || p.id === 'pack-foundation'),
    []
  );

  const referencePacks = useMemo(() => {
    const ids = new Set(REFERENCE_PACK_IDS);
    return prestations.filter((p) => ids.has(p.id as PackId));
  }, []);

  const premiumPack = useMemo(
    () => prestations.find((p) => p.id === 'pack-signature') ?? null,
    []
  );

  const selectedPack = selectedPackId ? PRESTATIONS_BY_ID.get(selectedPackId) ?? null : null;

  const includedSet = useMemo(() => new Set(includedModuleIds), [includedModuleIds]);
  const selectedModuleIdSet = useMemo(
    () => new Set(selectedModules.map((m) => m.id)),
    [selectedModules]
  );
  const manualIdSet = useMemo(() => new Set(manualModuleIds), [manualModuleIds]);

  const includedModules = useMemo(
    () => includedModuleIds.map((id) => MODULES_BY_ID.get(id)).filter(Boolean) as ModuleCatalogItem[],
    [includedModuleIds]
  );

  const addedModules = useMemo(() => {
    const extraIds = manualModuleIds.filter((id) => !includedSet.has(id));
    return extraIds
      .filter((id) => selectedModuleIdSet.has(id))
      .map((id) => MODULES_BY_ID.get(id))
      .filter(Boolean) as ModuleCatalogItem[];
  }, [manualModuleIds, includedSet, selectedModuleIdSet]);

  const handleSelectPack = (next: string) => {
    if (next === 'none') {
      setSelectedPackId(null);
      toast.info('Sélection "à la carte" activée.');
      return;
    }

    const packId = next as PackId;
    setSelectedPackId(packId);

    // The prestations list is synchronized by the effect bound to selectedPackId.
    // Avoid mutating prestations here to prevent redundant updates / loops.
    const pack = PRESTATIONS_BY_ID.get(packId);
    toast.success(`${pack?.name ?? 'Pack'} sélectionné`);
  };

  const handleToggleModule = (module: ModuleCatalogItem) => {
    if (includedSet.has(module.id)) {
      toast.info('Ce module est inclus via votre pack.');
      return;
    }

    const isSelected = selectedModuleIdSet.has(module.id);
    if (isSelected) {
      removeModule(module.id);
      toast.info(`${module.name} retiré de votre composition`);
    } else {
      addModule({ id: module.id, name: module.name, price: module.price, description: module.description });
      toast.success(`${module.name} ajouté à votre composition`);
    }
  };

  const handleResetOptions = () => {
    resetKeepingMandatory();
    toast.info('Votre composition a été réinitialisée (socle conservé).');
  };

  // --- Pack cards data ---
  const packCards = useMemo(() => {
    const withModules = (pack: Prestation) => {
      const packId = pack.id as PackId;
      const ids = PACK_INCLUDED_MODULE_IDS[packId] ?? [];
      const inc = ids.map((id) => MODULES_BY_ID.get(id)).filter(Boolean) as ModuleCatalogItem[];
      return { pack, included: inc };
    };
    const cards = referencePacks.map(withModules);
    // Signature last (if present)
    if (premiumPack) cards.push(withModules(premiumPack));
    return cards;
  }, [referencePacks, premiumPack]);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-24 lg:pb-16">
        {/* Hero */}
        <section className="py-16">
          <div className="section-container text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <span className="badge-amber mb-4 inline-block">Nos offres</span>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
                Votre <span className="text-gradient">carte</span>
              </h1>
              <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
                Un socle obligatoire (Audit + Foundation), puis un <strong>pack</strong> qui active automatiquement des
                modules — avec la possibilité de compléter <strong>à la carte</strong>.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="section-container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* MAIN */}
            <div className="lg:col-span-2 space-y-10">
              {/* Bloc 1: socle */}
              <section className="py-2" aria-labelledby="socle-title">
                <div className="mb-6">
                  <h2 id="socle-title" className="font-display text-2xl md:text-3xl font-bold mb-2">
                    Socle <span className="text-gradient">obligatoire</span>
                  </h2>
                  <p className="text-muted-foreground max-w-2xl">
                    L'audit est requis avant toute construction. Le pack Foundation constitue la base technique de votre
                    installation.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {mandatoryPrestations.map((prestation) => (
                    <PrestationCard key={prestation.id} prestation={prestation} isMandatory />
                  ))}
                </div>
              </section>

              {/* Bloc 2: choisir un pack */}
              <section className="py-2" aria-labelledby="packs-title">
                <div className="mb-6">
                  <h2 id="packs-title" className="font-display text-2xl md:text-3xl font-bold mb-2">
                    Choisir un <span className="text-gradient">pack</span>
                  </h2>
                  <p className="text-muted-foreground max-w-2xl">
                    Les packs sont des <strong>menus</strong> : ils activent automatiquement un ensemble de modules.
                  </p>
                </div>

                <RadioGroup
                  value={selectedPackId ?? 'none'}
                  onValueChange={handleSelectPack}
                  className="grid grid-cols-1 gap-6"
                >
                  <motion.div
                    layout
                    className={`relative rounded-2xl border p-6 transition-all duration-300 ${
                      !selectedPackId
                        ? 'bg-primary/10 border-primary shadow-glow'
                        : 'bg-card border-border hover:border-primary/30'
                    }`}
                    onClick={() => handleSelectPack('none')}
                  >
                    <div className="flex items-start gap-3">
                      <RadioGroupItem value="none" id="pack-none" aria-label="Aucun pack" />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-display text-lg md:text-xl font-bold">Aucun pack</h3>
                          <Badge variant="outline">À la carte</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-2">
                          Vous choisissez uniquement les modules qui vous intéressent.
                        </p>
                        <div className="mt-5">
                          <Button
                            type="button"
                            variant={!selectedPackId ? 'outline' : 'default'}
                            className="w-full sm:w-auto"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSelectPack('none');
                            }}
                          >
                            {!selectedPackId ? (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Sélection "à la carte"
                              </>
                            ) : (
                              <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Choisir "à la carte"
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  {packCards.map(({ pack, included }) => (
                    <PackCard
                      key={pack.id}
                      pack={pack}
                      value={selectedPackId ?? 'none'}
                      onSelect={handleSelectPack}
                      includedModules={included}
                      highlight={pack.id === 'pack-guardian' ? 'Recommandé' : undefined}
                    />
                  ))}
                </RadioGroup>
              </section>

              {/* Bloc 3: modules à la carte */}
              <section className="py-2" aria-labelledby="modules-title">
                <div className="mb-6">
                  <h2 id="modules-title" className="font-display text-2xl md:text-3xl font-bold mb-2">
                    Modules <span className="text-gradient">à la carte</span>
                  </h2>
                  <p className="text-muted-foreground max-w-2xl">
                    Les modules inclus par le pack sont marqués <strong>Inclus</strong> et verrouillés. Vous pouvez ajouter
                    d'autres modules en complément.
                  </p>
                </div>

                <div className="rounded-2xl border border-border bg-muted/20 p-4 mb-6">
                  <div className="flex flex-wrap gap-2 items-center">
                    <Badge variant="secondary" className="gap-1">
                      <Lock className="w-3.5 h-3.5" aria-hidden="true" /> Inclus
                    </Badge>
                    <Badge className="gap-1">
                      <Plus className="w-3.5 h-3.5" aria-hidden="true" /> Ajouté
                    </Badge>
                    <Badge variant="outline">Optionnel</Badge>
                    <span className="text-xs text-muted-foreground ml-auto">
                      Astuce : utilisez Tab / Espace pour naviguer au clavier.
                    </span>
                  </div>
                </div>

                <Accordion type="multiple" defaultValue={[MODULE_CATEGORIES[0]?.id ?? 'Sécurité']} className="rounded-2xl border border-border overflow-hidden">
                  {MODULE_CATEGORIES.map((cat) => {
                    const items = MODULES_CATALOG.filter((m) => m.category === cat.id);
                    if (items.length === 0) return null;
                    return (
                      <AccordionItem key={cat.id} value={cat.id} className="border-b border-border last:border-b-0">
                        <AccordionTrigger className="px-6">
                          <div className="flex items-center justify-between w-full">
                            <span className="font-display font-bold">{cat.label}</span>
                            <span className="text-xs text-muted-foreground mr-4">
                              {items.length} module{items.length > 1 ? 's' : ''}
                            </span>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="px-6">
                          <div className="grid grid-cols-1 gap-4">
                            {items.map((m) => {
                              const included = includedSet.has(m.id);
                              const selected = selectedModuleIdSet.has(m.id);
                              const manualSelected = manualIdSet.has(m.id) && !included;
                              return (
                                <ModuleMenuCard
                                  key={m.id}
                                  module={m}
                                  included={included}
                                  selected={selected}
                                  manualSelected={manualSelected}
                                  onToggle={() => handleToggleModule(m)}
                                />
                              );
                            })}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    );
                  })}
                </Accordion>

                <div className="mt-8 text-center">
                  <Link to="/modules" className="inline-flex">
                    <Button variant="outline" className="group">
                      Voir la page Modules (catalogue)
                      <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                    </Button>
                  </Link>
                </div>
              </section>

              {/* Bloc 4: recap (non-sticky, visible on all screens) */}
              <section className="py-2 lg:hidden">
                <SelectionSummary
                  selectedPack={selectedPack}
                  includedModules={includedModules}
                  addedModules={addedModules}
                  onReset={handleResetOptions}
                />
              </section>
            </div>

            {/* ASIDE SUMMARY (desktop) */}
            <aside className="hidden lg:block">
              <div className="sticky top-24">
                <SelectionSummary
                  selectedPack={selectedPack}
                  includedModules={includedModules}
                  addedModules={addedModules}
                  onReset={handleResetOptions}
                />
              </div>
            </aside>
          </div>
        </section>
      </main>

      {/* Mobile sticky recap */}
      <div className="sticky-cta lg:hidden">
        <div className="section-container">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-sm font-medium truncate">
                {selectedPack ? selectedPack.name : 'À la carte'}
              </p>
              <p className="text-xs text-muted-foreground">
                Inclus : {includedModules.length} • Ajoutés : {addedModules.length}
              </p>
            </div>
            <Button variant="hero" onClick={() => setSummaryOpen(true)} className="shrink-0">
              Récap
              <ArrowRight className="w-4 h-4 ml-2" aria-hidden="true" />
            </Button>
          </div>
        </div>
      </div>

      <Drawer open={summaryOpen} onOpenChange={setSummaryOpen}>
        <DrawerContent className="max-h-[85vh]">
          <DrawerHeader>
            <DrawerTitle>Récapitulatif</DrawerTitle>
            <DrawerDescription>
              Vérifiez votre pack, les modules inclus et vos ajouts à la carte.
            </DrawerDescription>
          </DrawerHeader>
          <div className="px-4 pb-4">
            <SelectionSummary
              selectedPack={selectedPack}
              includedModules={includedModules}
              addedModules={addedModules}
              onReset={handleResetOptions}
            />
          </div>
          <DrawerFooter>
            <DrawerClose asChild>
              <Button variant="outline">Fermer</Button>
            </DrawerClose>
          </DrawerFooter>
        </DrawerContent>
      </Drawer>

      <Footer />
    </div>
  );
}

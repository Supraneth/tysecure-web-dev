import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { 
  ArrowRight, 
  CheckCircle, 
  Clock, 
  FileText, 
  Shield, 
  Wifi,
  Server,
  Key,
  BookOpen,
  HeadphonesIcon,
  Zap,
  AlertTriangle
} from 'lucide-react';

const steps = [
  {
    number: '1',
    title: 'Audit par un expert cyberdéfense',
    subtitle: 'Étape 1',
    price: 'À partir de 750€ HT',
    priceNote: 'Prix déductible si le coût du projet est ≥ 5 000€',
    description: "Analyse complète de votre habitat, besoins, infrastructure réseau et électrique. Pas un rendez-vous commercial, un vrai diagnostic technique réalisé par un ingénieur cybersécurité.",
    quote: "L'audit évite les mauvaises surprises. 70% des projets mal préparés dérapent en budget et délai. Nous préférons investir du temps en amont pour livrer sereinement.",
    duration: 'Demi-journée sur site + rédaction (3-5 jours)',
    livrables: [
      'Visite sur site avec relevés et photos',
      'Rapport détaillé (15-20 pages)',
      'Schéma d\'architecture cible',
      'Matrice de couverture fonctionnelle',
      '+ 4 autres livrables'
    ],
    criteres: [
      'Faisabilité technique validée',
      'Budget aligné avec vos attentes',
      'Prérequis clairement identifiés',
      'Risques documentés'
    ],
    image: 'https://images.unsplash.com/photo-1581092921461-eab62e97a780?w=600&h=400&fit=crop',
    features: [
      { icon: FileText, text: 'Analyse des besoins et usages quotidiens' },
      { icon: Shield, text: 'Cartographie réseau et électrique' },
      { icon: AlertTriangle, text: 'Identification des contraintes techniques' }
    ]
  },
  {
    number: '2',
    title: 'Architecture, Construction et Intégration par TySecure',
    subtitle: 'Étape 2',
    price: 'À partir de 1 500€ HT',
    priceNote: 'Pour un pack TySecure Foundation - Hors matériel',
    description: "Conception et installation de votre système domotique sur-mesure. Architecture sécurisée, configuration des automatisations, tests de résilience. Chaque étape est documentée.",
    quote: "La phase Build est notre cœur de métier. Nous appliquons les standards industriels (segmentation, durcissement, monitoring) adaptés à l'habitat. Pas de bricolage.",
    duration: '2 à 5 jours selon complexité',
    livrables: [
      'Architecture réseau sécurisée (VLAN/SSID)',
      'Serveur Home Assistant durci',
      'Configuration des intégrations (Zigbee, Z-Wave, WiFi)',
      'Création des automatisations et scènes',
      '+ 4 autres livrables'
    ],
    criteres: [
      'Tous les scénarios fonctionnels',
      'Tests de résilience passés',
      'Documentation à jour',
      'PV de recette signé'
    ],
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop',
    features: [
      { icon: Server, text: 'Installation Home Assistant sécurisée' },
      { icon: Wifi, text: 'Architecture réseau VLAN' },
      { icon: Zap, text: 'Configuration automatisations' }
    ]
  },
  {
    number: '3',
    title: 'Livraison, Formation et Accompagnement',
    subtitle: 'Étape 3',
    price: "À partir de 39€/mois",
    priceNote: "Pour la souscription d'un plan d'accompagnement Care Standard",
    description: "Transfert complet des clés et connaissances, puis maintenance proactive optionnelle par abonnement mensuel. Votre maison reste fonctionnelle dans le temps, avec un support humain et réactif.",
    quote: "Le handover est la preuve de notre engagement qualité. Vous repartez avec tout : accès, documentation, procédures. Nous restons disponibles via Care pour le suivi.",
    duration: 'Formation initiale + suivi continu',
    livrables: [
      'Clés et accès administrateur complets',
      'Runbooks opérationnels illustrés',
      'Procédures de sauvegarde/restauration',
      'Formation utilisateur (1-2h)',
      '+ 4 autres livrables'
    ],
    criteres: [
      'Client autonome sur les opérations de base',
      'Sauvegardes testées et validées',
      'Contact support établi',
      'Documentation acceptée'
    ],
    image: 'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=600&h=400&fit=crop',
    features: [
      { icon: Key, text: 'Clés et accès complets transférés' },
      { icon: BookOpen, text: 'Runbooks et procédures' },
      { icon: HeadphonesIcon, text: 'Support Care dédié' }
    ]
  }
];

const resilienceTests = [
  { 
    title: 'Test perte Internet', 
    description: 'Vérification que tous les scénarios locaux fonctionnent sans connexion externe. Simulation de coupure FAI.' 
  },
  { 
    title: 'Test UPS / coupure secteur', 
    description: "Simulation de coupure électrique, validation de l'arrêt propre du serveur et des équipements critiques." 
  },
  { 
    title: 'Test restauration complète', 
    description: 'Restauration intégrale depuis sauvegarde sur système vierge. Validation du temps de reprise < 2h.' 
  },
  { 
    title: 'Validation accès client', 
    description: 'Vérification que le client possède tous les accès administrateur, mots de passe, et clés de chiffrement.' 
  }
];

function ProcessStep({ step, index }: { step: typeof steps[0]; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [50, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);
  const isEven = index % 2 === 0;

  return (
        <section
          ref={ref}
          id={step.number === '1' ? 'audit' : step.number === '2' ? 'build' : step.number === '3' ? 'care' : undefined}
          className="py-16 md:py-24 relative overflow-hidden scroll-mt-24"
        >
        <div className="section-container">
        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${isEven ? '' : 'lg:flex-row-reverse'}`}>
          {/* Image with parallax */}
          <motion.div 
            style={{ y }}
            className={`relative ${isEven ? 'lg:order-1' : 'lg:order-2'}`}
          >
            <div className="relative rounded-2xl overflow-hidden shadow-elevated">
              <img 
                src={step.image} 
                alt={step.title}
                className="w-full h-64 md:h-96 object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
              
              {/* Feature badges */}
              <div className="absolute bottom-4 left-4 right-4 flex flex-wrap gap-2">
                {step.features.map((feature, i) => (
                  <div 
                    key={i}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-background/90 backdrop-blur-sm text-sm"
                  >
                    <feature.icon className="w-4 h-4 text-primary" />
                    <span className="text-foreground text-xs">{feature.text}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Step indicator */}
            <div className="absolute -top-4 -left-4 md:-top-6 md:-left-6 step-indicator text-2xl md:text-3xl">
              {step.number}
            </div>
          </motion.div>

          {/* Content */}
          <motion.div 
            style={{ opacity }}
            className={`${isEven ? 'lg:order-2' : 'lg:order-1'}`}
          >
            <span className="text-primary text-sm font-medium">{step.subtitle}</span>
            <h2 className="font-display text-3xl md:text-4xl font-bold mt-2 mb-4">
              {step.title}
            </h2>
            
            <div className="flex flex-wrap items-baseline gap-3 mb-6">
              <span className="price-tag text-2xl md:text-3xl">{step.price}</span>
              {step.priceNote && (
                <span className="text-primary/80 text-sm">— {step.priceNote}</span>
              )}
            </div>

            <p className="text-muted-foreground mb-6 leading-relaxed">
              {step.description}
            </p>

            {/* Quote */}
            <blockquote className="border-l-2 border-primary/50 pl-4 py-2 mb-6 bg-primary/5 rounded-r-lg">
              <p className="text-sm text-muted-foreground italic">
                "{step.quote}"
              </p>
            </blockquote>

            {/* Duration */}
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
              <Clock className="w-4 h-4 text-primary" />
              <span><strong>Durée :</strong> {step.duration}</span>
            </div>

            {/* Livrables */}
            <div className="mb-6">
              <h4 className="font-display font-semibold mb-3">Livrables clés</h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {step.livrables.map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            {/* Critères */}
            <div className="p-4 rounded-xl bg-card border border-border">
              <h4 className="font-display font-semibold mb-3 text-sm">Critères de réussite</h4>
              <ul className="space-y-2">
                {step.criteres.map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            {step.number === '1' && (
            <div className="mt-8">
              <Button asChild variant="hero" size="lg" className="group">
                <a href="#build">
                  Continuer avec l&apos;étape 2
                  <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
                </a>
              </Button>
            </div>
          )}

          {step.number === '2' && (
            <div className="mt-8">
              <Button asChild variant="hero" size="lg" className="group">
                <a href="#care">
                  Continuer vers l&apos;étape 3
                  <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
                </a>
              </Button>
            </div>
          )}
          {step.number === '3' && (
            <div className="mt-8">
              <Link to="/prestations" className="inline-block">
                <Button
                  variant="hero"
                  size="lg"
                  className="group relative overflow-hidden"
                >
                  {/* halo animé */}
                  <span className="pointer-events-none absolute inset-0 opacity-60 animate-pulse bg-primary/20" />
                  <span className="group relative overflow-hidden bg-amber-500 text-black hover:bg-amber-400 flex items-center">
                    Prêt à démarrer ?
                    <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
                  </span>
                </Button>
              </Link>

              {/* mini-texte optionnel (très efficace UX) */}
              <p className="mt-2 text-xs text-muted-foreground">
                Choisissez une prestation (packs recommandés ou modules) avant l’audit.
              </p>
            </div>
          )}
          </motion.div>
        </div>
      </div>
    </section>
  );
  
}

function ResilienceSection() {
}

function ProcessCTA() {
}

export default function Process() {
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });
  
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero with parallax */}
        <section ref={heroRef} className="relative min-h-[70vh] flex items-center pt-20 overflow-hidden">
          <motion.div style={{ y: heroY }} className="absolute inset-0">
            <div className="absolute inset-0 bg-gradient-hero" />
            <div className="absolute inset-0 bg-grid opacity-30" />
          </motion.div>
          
          <motion.div style={{ opacity: heroOpacity }} className="section-container relative z-10 text-center">
            <span className="badge-amber mb-4 inline-block">Comment se déroule un partenariat avec TySecure ?</span>
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
              Audit → <span className="text-gradient">Construction</span> → Accompagnement
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
              Trois étapes claires avec des livrables concrets et des critères de réussite définis. 
              Pas de zone grise, pas de surprise. Une méthodologie éprouvée pour des projets maîtrisés.
            </p>
            <Button asChild variant="hero" size="lg">
              <a href="#audit">Comprendre les étapes ⬇️</a>
            </Button>
          </motion.div>
        </section>

        {/* Steps */}
        {steps.map((step, index) => (
        <ProcessStep key={step.title} step={step} index={index} />
        ))}

        <ResilienceSection />
        <ProcessCTA />
      </main>

      <Footer />
    </div>
  );
}

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Prestation {
  id: string;
  name: string;
  price: string;
  description: string;
}

export interface Module {
  id: string;
  name: string;
  price: string;
  description: string;
}

export interface Aftercare {
  id: string;
  name: string;
  price: string;
  description: string;
  features: string[];
}

// Prestations always included by default in the offers flow.
// They should not be treated as "items" in the cart badge / short summaries.
export const MANDATORY_PRESTATION_IDS = new Set<string>(['audit', 'pack-foundation']);

// Modules that must remain in the composition even after a reset.
// (Empty by default — fill with IDs when needed, e.g. 'cyber'.)
export const MANDATORY_MODULE_IDS = new Set<string>([]);

interface CompositionState {
  prestations: Prestation[];
  modules: Module[];
  selectedAftercare: Aftercare | null;
  
  addPrestation: (prestation: Prestation) => void;
  removePrestation: (id: string) => void;
  addModule: (module: Module) => void;
  removeModule: (id: string) => void;
  // Keep both names to avoid breaking pages/components that still use an older prop name.
  setAftercare: (aftercare: Aftercare | null) => void;
  setSelectedAftercare: (aftercare: Aftercare | null) => void;
  clearAll: () => void;
  resetKeepingMandatory: () => void;
  getTotalItems: () => number;
}

export const useComposition = create<CompositionState>()(
  persist(
    (set, get) => ({
      prestations: [],
      modules: [],
      selectedAftercare: null,

      addPrestation: (prestation) =>
        set((state) => {
          if (state.prestations.find((p) => p.id === prestation.id)) {
            return state;
          }
          return { prestations: [...state.prestations, prestation] };
        }),

      removePrestation: (id) =>
        set((state) => ({
          prestations: state.prestations.filter((p) => p.id !== id),
        })),

      addModule: (module) =>
        set((state) => {
          if (state.modules.find((m) => m.id === module.id)) {
            return state;
          }
          return { modules: [...state.modules, module] };
        }),

      removeModule: (id) =>
        set((state) => ({
          modules: state.modules.filter((m) => m.id !== id),
        })),

      setAftercare: (aftercare) =>
        set({ selectedAftercare: aftercare }),

      setSelectedAftercare: (aftercare) =>
        set({ selectedAftercare: aftercare }),

      clearAll: () =>
        set({ prestations: [], modules: [], selectedAftercare: null }),

      resetKeepingMandatory: () =>
        set((state) => ({
          prestations: state.prestations.filter((p) => MANDATORY_PRESTATION_IDS.has(p.id)),
          modules: state.modules.filter((m) => MANDATORY_MODULE_IDS.has(m.id)),
          selectedAftercare: null
        })),

      getTotalItems: () => {
        const state = get();
        const visiblePrestationsCount = state.prestations.filter(
          (p) => !MANDATORY_PRESTATION_IDS.has(p.id)
        ).length;
        const visibleModulesCount = state.modules.filter((m) => !MANDATORY_MODULE_IDS.has(m.id)).length;
        return visiblePrestationsCount + visibleModulesCount + (state.selectedAftercare ? 1 : 0);
      },
    }),
    {
      name: 'tysecure-composition',
    }
  )
);
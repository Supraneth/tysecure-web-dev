import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { useComposition, type Module } from '@/hooks/useComposition';
import { 
  ArrowRight, 
  Plus,
  Check,
  Lightbulb,
  Thermometer,
  Video,
  Lock,
  Droplets,
  Zap,
  Music,
  ShieldCheck
} from 'lucide-react';
import { toast } from 'sonner';

const modules: (Module & { icon: typeof Lightbulb })[] = [
  {
    id: 'eclairage',
    name: 'Éclairage Intelligent',
    price: '490€ HT',
    description: 'Gestion centralisée de l\'éclairage, scénarios ambiance, détection de présence, programmation circadienne.',
    icon: Lightbulb
  },
  {
    id: 'chauffage',
    name: 'Gestion Thermique',
    price: '690€ HT',
    description: 'Thermostat connecté, zones de chauffage, programmation avancée, intégration pompe à chaleur.',
    icon: Thermometer
  },
  {
    id: 'video',
    name: 'Vidéosurveillance',
    price: '890€ HT',
    description: 'Caméras IP locales, enregistrement NVR, détection IA, notifications intelligentes.',
    icon: Video
  },
  {
    id: 'alarme',
    name: 'Alarme & Intrusion',
    price: '790€ HT',
    description: 'Système d\'alarme intégré, capteurs d\'ouverture, sirène, modes jour/nuit/absent.',
    icon: Lock
  },
  {
    id: 'arrosage',
    name: 'Gestion de l\'Eau',
    price: '390€ HT',
    description: 'Arrosage automatique, détection de fuites, relevé de compteur, alertes consommation.',
    icon: Droplets
  },
  {
    id: 'energie',
    name: 'Monitoring Énergétique',
    price: '590€ HT',
    description: 'Suivi consommation temps réel, délestage, intégration panneaux solaires, dashboard dédié.',
    icon: Zap
  },
  {
    id: 'multiroom',
    name: 'Audio Multiroom',
    price: '690€ HT',
    description: 'Sonos/Cast intégré, scénarios musicaux, commande vocale locale, synchronisation zones.',
    icon: Music
  },
  {
    id: 'cyber',
    name: 'Pack Cyber+',
    price: '990€ HT',
    description: 'Durcissement avancé, DNS Guard, VPN site-to-site, audit sécurité trimestriel.',
    icon: ShieldCheck
  }
];

function ModuleCard({ module }: { module: typeof modules[0] }) {
  const { modules: selectedModules, addModule, removeModule } = useComposition();
  const isSelected = selectedModules.some(m => m.id === module.id);
  const Icon = module.icon;

  const handleToggle = () => {
    if (isSelected) {
      removeModule(module.id);
      toast.info(`${module.name} retiré de votre composition`);
    } else {
      addModule({ id: module.id, name: module.name, price: module.price, description: module.description });
      toast.success(`${module.name} ajouté à votre composition`);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`relative p-6 rounded-2xl border transition-all duration-300 ${
        isSelected 
          ? 'bg-primary/10 border-primary shadow-glow' 
          : 'bg-card border-border hover:border-primary/30'
      }`}
    >
      {isSelected && (
        <div className="absolute top-4 right-4">
          <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
            <Check className="w-4 h-4 text-primary-foreground" />
          </div>
        </div>
      )}

      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
        <Icon className="w-6 h-6 text-primary" />
      </div>
      
      <h3 className="font-display text-lg font-bold mb-2">{module.name}</h3>
      <p className="price-tag text-xl mb-3">{module.price}</p>
      <p className="text-muted-foreground text-sm mb-6">{module.description}</p>
      
      <Button 
        variant={isSelected ? "outline" : "default"}
        className="w-full"
        onClick={handleToggle}
      >
        {isSelected ? (
          <>
            <Check className="w-4 h-4 mr-2" />
            Sélectionné
          </>
        ) : (
          <>
            <Plus className="w-4 h-4 mr-2" />
            Ajouter
          </>
        )}
      </Button>
    </motion.div>
  );
}

export default function Modules() {
  const { getTotalItems } = useComposition();
  const totalItems = getTotalItems();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-24 pb-16">
        {/* Hero */}
        <section className="py-16">
          <div className="section-container text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <span className="badge-amber mb-4 inline-block">Extensions</span>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
                Modules <span className="text-gradient">complémentaires</span>
              </h1>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Enrichissez votre installation avec des fonctionnalités spécialisées. 
                Chaque module est conçu pour s'intégrer parfaitement à votre système.
              </p>
              <div className="mt-8 flex justify-center">
                <Link to="/accompagnement#offres">
                  <Button variant="secondary" className="group">
                    Compléter avec une offre d'accompagnement
                    <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Modules grid */}
        <section className="py-8">
          <div className="section-container">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {modules.map((module) => (
                <ModuleCard key={module.id} module={module} />
              ))}
            </div>
          </div>
        </section>

        {/* CTA to Composition */}
        <section className="py-16">
          <div className="section-container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center p-8 md:p-12 rounded-2xl bg-card border border-border"
            >
              <h2 className="font-display text-2xl md:text-3xl font-bold mb-4">
                Voir ma <span className="text-gradient">composition</span>
              </h2>
              <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
                {totalItems > 0 
                  ? `Vous avez ${totalItems} élément${totalItems > 1 ? 's' : ''} dans votre composition. Finalisez votre sélection et choisissez votre plan de maintenance.`
                  : 'Ajoutez des prestations et modules pour construire votre solution sur-mesure.'}
              </p>
              <Link to="/composition">
                <Button variant="hero" size="lg" className="group">
                  {totalItems > 0 ? 'Voir ma composition' : 'Accéder à la composition'}
                  <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { useComposition, type Prestation } from '@/hooks/useComposition';
import {
  ArrowRight,
  CheckCircle,
  Plus,
  Check,
  FileText,
  Home,
  Shield,
  Settings
} from 'lucide-react';
import { toast } from 'sonner';

import { PRESTATIONS_CATALOG } from '@/data/prestations';

const prestations: Prestation[] = PRESTATIONS_CATALOG;

const features = [
  { icon: FileText, text: 'Documentation complÃÂ¨te' },
  { icon: Home, text: 'Installation sur site' },
  { icon: Shield, text: 'CybersÃÂ©curitÃÂ©' },
  { icon: Settings, text: 'Support technique' }
];

function PrestationCard({
  prestation,
  isMandatory = false
}: {
  prestation: Prestation;
  isMandatory?: boolean;
}) {
  const { prestations: selectedPrestations, addPrestation, removePrestation } = useComposition();
  const isSelected = selectedPrestations.some((p) => p.id === prestation.id);

  const handleToggle = () => {
    if (isMandatory) {
      toast.info('Cette prestation est obligatoire.');
      return;
    }

    if (isSelected) {
      removePrestation(prestation.id);
      toast.info(`${prestation.name} retirÃÂ© de votre composition`);
    } else {
      addPrestation(prestation);
      toast.success(`${prestation.name} ajoutÃÂ© ÃÂ  votre composition`);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`relative p-6 rounded-2xl border transition-all duration-300 ${
        isSelected || isMandatory
          ? 'bg-primary/10 border-primary shadow-glow'
          : 'bg-card border-border hover:border-primary/30'
      }`}
    >
      {(isSelected || isMandatory) && (
        <div className="absolute top-4 right-4">
          <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
            <Check className="w-4 h-4 text-primary-foreground" />
          </div>
        </div>
      )}

      <div className="flex items-start justify-between gap-3 mb-2">
        <h3 className="font-display text-xl font-bold">{prestation.name}</h3>
        {isMandatory && (
          <span className="text-xs font-medium px-2 py-1 rounded-full bg-primary/10 text-primary shrink-0">
            Obligatoire
          </span>
        )}
      </div>

      <p className="price-tag text-2xl mb-4">{prestation.price}</p>
      <p className="text-muted-foreground text-sm mb-6">{prestation.description}</p>

      <Button
        variant={isSelected || isMandatory ? 'outline' : 'default'}
        className="w-full"
        onClick={handleToggle}
      >
        {isMandatory ? (
          <>
            <CheckCircle className="w-4 h-4 mr-2" />
            Inclus (obligatoire)
          </>
        ) : isSelected ? (
          <>
            <Check className="w-4 h-4 mr-2" />
            SÃÂ©lectionnÃÂ©
          </>
        ) : (
          <>
            <Plus className="w-4 h-4 mr-2" />
            Ajouter ÃÂ  ma composition
          </>
        )}
      </Button>
    </motion.div>
  );
}

export default function Prestations() {
  const { prestations: selectedPrestations, addPrestation } = useComposition();

  // Force audit + foundation to be present (idempotent)
  useEffect(() => {
    const mandatoryIds = new Set(['audit', 'pack-foundation']);
    const selectedIds = new Set(selectedPrestations.map((p) => p.id));

    prestations.forEach((p) => {
      if (mandatoryIds.has(p.id) && !selectedIds.has(p.id)) {
        addPrestation(p);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const mandatory = prestations.filter((p) => p.id === 'audit' || p.id === 'pack-foundation');
  const optional = prestations.filter(
    (p) => p.id === 'pack-sentinel' || p.id === 'pack-cyber' || p.id === 'pack-guardian'
  );
  const premium = prestations.find((p) => p.id === 'pack-signature');

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-16">
        {/* Hero */}
        <section className="py-16">
          <div className="section-container text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <span className="badge-amber mb-4 inline-block">Nos offres</span>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
                Nos <span className="text-gradient">Prestations</span>
              </h1>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
                Un socle obligatoire (Audit + Foundation), puis des packs optionnels selon votre besoin.
              </p>

              {/* Features */}
              <div className="flex flex-wrap justify-center gap-4 mb-8">
                {features.map((feature) => (
                  <div
                    key={feature.text}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border"
                  >
                    <feature.icon className="w-4 h-4 text-primary" />
                    <span className="text-sm">{feature.text}</span>
                  </div>
                ))}
              </div>


              <div className="flex justify-center">
                <Link to="/accompagnement#offres">
                  <Button variant="secondary" className="group">
                    Compléter avec une offre d'accompagnement
                    <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>


        {/* Obligatoire */}
        <section className="py-8">
          <div className="section-container">
            <div className="mb-6">
              <h2 className="font-display text-2xl md:text-3xl font-bold mb-2">
                Socle <span className="text-gradient">obligatoire</span>
              </h2>
              <p className="text-muted-foreground max-w-2xl">
                LÃ¢ÂÂAudit est requis avant toute construction. Le pack Foundation constitue la base technique de votre
                installation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mandatory.map((prestation) => (
                <PrestationCard key={prestation.id} prestation={prestation} isMandatory />
              ))}
            </div>
          </div>
        </section>

        {/* Packs optionnels */}
        <section className="py-8">
          <div className="section-container">
            <div className="mb-6">
              <h2 className="font-display text-2xl md:text-3xl font-bold mb-2">
                Packs <span className="text-gradient">optionnels</span>
              </h2>
              <p className="text-muted-foreground max-w-2xl">
                Choisissez selon votre besoin : sÃÂ©curitÃÂ© physique, cybersÃÂ©curitÃÂ© avancÃÂ©e, ou une offre tout-en-un.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {optional.map((prestation) => (
                <PrestationCard key={prestation.id} prestation={prestation} />
              ))}
            </div>
          </div>
        </section>

        {/* Premium */}
        {premium && (
          <section className="py-8">
            <div className="section-container">
              <div className="mb-6">
                <h2 className="font-display text-2xl md:text-3xl font-bold mb-2">
                  Offre <span className="text-gradient">premium</span>
                </h2>
                <p className="text-muted-foreground max-w-2xl">
                  Pour des besoins trÃÂ¨s spÃÂ©cifiques (sites complexes, exigences ÃÂ©levÃÂ©es, intÃÂ©grations avancÃÂ©es).
                </p>
              </div>

              <div className="grid grid-cols-1">
                <PrestationCard prestation={premium} />
              </div>
            </div>
          </section>
        )}

        {/* CTA to Modules */}
        <section className="py-16">
          <div className="section-container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center p-8 md:p-12 rounded-2xl bg-gradient-to-r from-primary/10 via-card to-primary/10 border border-border"
            >
              <h2 className="font-display text-2xl md:text-3xl font-bold mb-4">
                ComplÃÂ©ter votre prestation avec des <span className="text-gradient">modules</span>
              </h2>
              <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
                Ajoutez des fonctionnalitÃÂ©s spÃÂ©cifiques ÃÂ  votre installation : ÃÂ©clairage intelligent, gestion
                ÃÂ©nergÃÂ©tique, sÃÂ©curitÃÂ© avancÃÂ©e...
              </p>
              <Link to="/modules">
                <Button variant="hero" size="lg" className="group">
                  DÃÂ©couvrir les modules
                  <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
